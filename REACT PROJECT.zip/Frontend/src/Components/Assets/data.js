import p1_img from './product_16.png'
import p2_img from './product_20.png'
import p3_img from './product_17.png'
import p4_img from './product_23.png'

let data_product = [
  {
    id:4,
    name:"RAIN COAT",
    image:p1_img,
    new_price:6599,
    old_price:7599,
  },
  {id:3,
    name:"BLUE JACKET",
    image:p2_img,
    new_price:4599,
    old_price:6599,
  },
  {id:1,
    name:"DENIM JACKET",
    image:p3_img,
    new_price:5999,
    old_price:6999,
  },
  {id:2,
    name:"GREEN JACKET",
    image:p4_img,
    new_price:4999,
    old_price:5999,
  },
];

export default data_product;
